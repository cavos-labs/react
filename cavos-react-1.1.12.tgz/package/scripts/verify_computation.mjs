import { hash } from 'starknet';

const jwt_sub = '0x5f79f75f9a73edc7a';
const salt = '0x1';

console.log('jwt_sub:', jwt_sub);
console.log('salt:', salt);

// Compute Poseidon(jwt_sub, salt) - 2 elements
const computed = hash.computePoseidonHash(jwt_sub, salt);
console.log('Computed addressSeed:', computed);
console.log('Expected addressSeed:', '0x47fb8961fb991d179dea01ec246ecbd99d566ad5dcb993fd7594f9abac39b36');
console.log('Match:', computed === '0x47fb8961fb991d179dea01ec246ecbd99d566ad5dcb993fd7594f9abac39b36');
