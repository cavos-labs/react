
import { Account, RpcProvider, Contract, num, constants } from 'starknet';
import fetch from 'node-fetch';

const REGISTRY_ADDRESS = '0x05a19f14719dec9e27eb2aa38c5b68277bdb5c41570e548504722f737a3da6c6';
const RPC_URL = 'https://starknet-sepolia.g.alchemy.com/starknet/version/rpc/v0_10/dql5pMT88iueZWl7L0yzT56uVk0EBU4L';
const ACCOUNT_ADDRESS = '0x3d57e5e7421a70396a69274e8dd57dadfc5e38541d27e7a742116c3ef34bb33';
const PRIVATE_KEY = '0x4f7f6f0f318769325539bad869cde209e2cc559753517b9a825314bc393ede';

// Helper to convert base64url to BigInt
function base64UrlToBigInt(base64url) {
    const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
    const buffer = Buffer.from(base64, 'base64');
    return BigInt('0x' + buffer.toString('hex'));
}

// Helper to convert string to truncated felt (matching SDK)
function stringToFelt(str) {
    const bytes = Buffer.from(str, 'utf8');
    let result = 0n;
    const len = Math.min(bytes.length, 31);
    for (let i = 0; i < len; i++) {
        result = result * 256n + BigInt(bytes[i]);
    }
    return "0x" + result.toString(16);
}

// Helper to split BigInt into 16 u128 limbs (little-endian)
function toU128Limbs(n) {
    const limbs = [];
    for (let i = 0; i < 16; i++) {
        const limb = (n >> (BigInt(i) * 128n)) & ((1n << 128n) - 1n);
        limbs.push("0x" + limb.toString(16));
    }
    return limbs;
}

// Helper: provider felt (Poseidon("google")) or just string?
// Contracts says: pub provider: felt252.
// Usually hash of 'google'.
// Let's use stringToFelt('google').
function getProviderFelt() {
    return stringToFelt('google');
}

async function main() {
    console.log('Provider URL:', RPC_URL);
    console.log('Account Address:', ACCOUNT_ADDRESS);
    const provider = new RpcProvider({ nodeUrl: RPC_URL });
    // const account = new Account(provider, ACCOUNT_ADDRESS, PRIVATE_KEY);

    console.log('Fetching keys from Google...');
    const response = await fetch('https://www.googleapis.com/oauth2/v3/certs');
    const jwks = await response.json();

    for (const key of jwks.keys) {
        if (key.kty !== 'RSA' || key.alg !== 'RS256') continue;

        console.log(`Processing key KID: ${key.kid}`);
        const n = base64UrlToBigInt(key.n);
        const kid_felt = stringToFelt(key.kid);
        const limbs = toU128Limbs(n);
        const provider_felt = getProviderFelt();

        // Construct Calldata for set_key(kid, key)
        // key struct: n0..n15, provider, valid_until, is_active
        const key_struct = [
            ...limbs,
            provider_felt,
            0, // valid_until (0 = infinite)
            1  // is_active (true)
        ];

        const calldata = [kid_felt, ...key_struct];

        console.log(`\n=== Calldata for key ${key.kid} ===`);
        console.log(calldata.join(' '));
        console.log('=====================================\n');

        /*
        console.log(`Sending tx to set key ${key.kid}...`);
        try {
            const { transaction_hash } = await account.execute({
                contractAddress: REGISTRY_ADDRESS,
                entrypoint: 'set_key',
                calldata: calldata
            });
            console.log(`Transaction submitted: ${transaction_hash}`);
            await provider.waitForTransaction(transaction_hash);
            console.log(`Key ${key.kid} set successfully.`);
        } catch (e) {
            console.error(`Failed to set key ${key.kid}:`, e);
            // Continue with other keys
        }
        */
    }
}

main();
