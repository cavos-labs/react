import { hash } from 'starknet';

const jwt_sub = '0x5f79f75f9a73edc7a';
const salt = '0x1';

// Method 1: computePoseidonHash (2 parameters)
const method1 = hash.computePoseidonHash(jwt_sub, salt);
console.log('Method 1 - computePoseidonHash(a, b):', method1);

// Method 2: computePoseidonHashOnElements (array)
const method2 = hash.computePoseidonHashOnElements([jwt_sub, salt]);
console.log('Method 2 - computePoseidonHashOnElements([a, b]):', method2);

console.log('Are they the same?', method1 === method2);
