
import { Contract, RpcProvider, num } from 'starknet'; //v5 syntax
import fetch from 'node-fetch';

const REGISTRY_ADDRESS = '0x05a19f14719dec9e27eb2aa38c5b68277bdb5c41570e548504722f737a3da6c6';
const KID = '8630a71bd6ec1c61257a27ff2efd91872ecab1f6';
const RPC_URL = 'https://starknet-sepolia.g.alchemy.com/starknet/version/rpc/v0_10/dql5pMT88iueZWl7L0yzT56uVk0EBU4L';

const REGISTRY_ABI = [
    {
        "name": "get_public_key",
        "type": "function",
        "inputs": [
            { "name": "kid", "type": "core::felt252" }
        ],
        "outputs": [
            { "name": "modulus", "type": "u256" }, // Approximation, it returns BigUint2048 struct
            { "name": "exponent", "type": "u256" }
        ],
        "state_mutability": "view"
    }
];

// Helper to convert base64url to hex
function base64UrlToBigInt(base64url) {
    const base64 = base64url.replace(/-/g, '+').replace(/_/g, '/');
    const buffer = Buffer.from(base64, 'base64');
    return BigInt('0x' + buffer.toString('hex'));
}

async function main() {
    console.log(`Checking KID: ${KID}`);

    // 1. Fetch from Google
    console.log('Fetching from Google...');
    const response = await fetch('https://www.googleapis.com/oauth2/v3/certs');
    const jwks = await response.json();
    const key = jwks.keys.find(k => k.kid === KID);
    if (!key) {
        console.error('Key not found in Google JWKS!');
        return;
    }
    const n_google = base64UrlToBigInt(key.n);
    console.log(`Google Modulus (n): ${n_google.toString(16).substring(0, 32)}...`);

    // 2. Fetch from Contract
    console.log('Fetching from On-Chain Registry...');
    const provider = new RpcProvider({ nodeUrl: RPC_URL });

    // Manual call because ABI might be complex with structs
    // selector for get_public_key is sn_keccak("get_public_key")
    // args: [kid_felt]

    // KID string to felt (if implementation uses string_to_felt logic or just hash?)
    // The contract uses `kid` as felt. 
    // In `OAuthWalletManager.ts`: stringToFelt.

    function stringToFelt(str) {
        // Match SDK: truncate to 31 chars!
        const bytes = Buffer.from(str, 'utf8');
        let result = 0n;
        const len = Math.min(bytes.length, 31);
        for (let i = 0; i < len; i++) {
            result = result * 256n + BigInt(bytes[i]);
        }
        return "0x" + result.toString(16);
    }

    const kid_felt = stringToFelt(KID);
    console.log(`KID Felt: ${kid_felt}`);

    try {
        const result = await provider.callContract({
            contractAddress: REGISTRY_ADDRESS,
            entrypoint: 'get_key',
            calldata: [kid_felt]
        });

        console.log('Raw Result:', result);

        // Result is BigUint2048 { limbs: [u128; 16] }, BigUint2048 { limbs: [u128; 16] }
        // Each BigUint is 16 felts.
        // Total 32 felts.

        const modulus_limbs = result.slice(0, 16);
        let n_chain = 0n;
        // Limbs are u128, little endian?
        // BigUint2048 struct in bignum.cairo: limbs: [u128; 16] (little endian)

        for (let i = 0; i < 16; i++) {
            const limb = BigInt(modulus_limbs[i]);
            n_chain += limb * (1n << (BigInt(i) * 128n));
        }

        console.log(`Chain Modulus (n):  ${n_chain.toString(16).substring(0, 32)}...`);

        if (n_google === n_chain) {
            console.log("SUCCESS: Keys MATCH!");
        } else {
            console.error("FAILURE: Keys DO NOT MATCH!");
            console.error("This explains the verification failure. The contract has an old or different key.");
        }

    } catch (e) {
        console.error("Error calling contract:", e);
    }
}

main();
