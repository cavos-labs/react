import { hash, num } from 'starknet';

const sub = "110076830332326173818";
const salt = "0x1";

// Convert sub to felt
const subBigInt = BigInt(sub);
const subFelt = num.toHex(subBigInt);

console.log("sub:", sub);
console.log("subFelt:", subFelt);
console.log("salt:", salt);

// Compute address_seed = Poseidon(sub, salt)
const addressSeed = hash.computePoseidonHash(subFelt, salt);
console.log("Computed addressSeed:", addressSeed);
console.log("Expected addressSeed:", "0x47fb8961fb991d179dea01ec246ecbd99d566ad5dcb993fd7594f9abac39b36");
console.log("Match:", addressSeed === "0x47fb8961fb991d179dea01ec246ecbd99d566ad5dcb993fd7594f9abac39b36");
