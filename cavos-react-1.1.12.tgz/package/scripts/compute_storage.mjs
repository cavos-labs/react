import { hash } from 'starknet';

// Storage variables in Cairo have specific addresses
// For simple storage vars, it's typically based on the variable name
const key = hash.getSelectorFromName("address_seed");
console.log("Storage key for address_seed:", key);

// Also try the storage base (just incrementing from 0)
console.log("Simple slot 0:", "0x0");
console.log("Simple slot 1:", "0x1");
